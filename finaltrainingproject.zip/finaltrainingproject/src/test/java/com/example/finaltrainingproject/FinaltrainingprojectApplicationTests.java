package com.example.finaltrainingproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinaltrainingprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
