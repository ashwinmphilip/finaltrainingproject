package com.example.finaltrainingproject.service;

import com.example.finaltrainingproject.dto.ShowAcademicDetailsConfirmation;
import com.example.finaltrainingproject.dto.StudentCourseConfirmation;
import com.example.finaltrainingproject.dto.StudentCourseRequest;
import com.example.finaltrainingproject.dto.StudentDetailsRequest;

public interface MyStudentDetailsService {
	
	public ShowAcademicDetailsConfirmation updateStudent(StudentDetailsRequest studentDetailsRequest, Long id);
	public ShowAcademicDetailsConfirmation showStudent(Long id);
	public StudentCourseConfirmation updateStudentCourse(StudentCourseRequest studentCourseRequest, Long id);
	
}