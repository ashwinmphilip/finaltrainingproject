package com.example.finaltrainingproject.exception;

public class ObjectInUseException extends RuntimeException{
	public ObjectInUseException(String message) {
		super(message);
	}
}
