package com.example.finaltrainingproject.service;

import com.example.finaltrainingproject.dto.CourseRequest;
import com.example.finaltrainingproject.dto.ShowCourseConfirmation;
import com.example.finaltrainingproject.dto.ShowCourseListConfirmation;
import com.example.finaltrainingproject.dto.ShowCustomStudentListConfirmation;
import com.example.finaltrainingproject.dto.ShowStudentDetailsListConfirmation;
import com.example.finaltrainingproject.dto.StudentConfirmation;
import com.example.finaltrainingproject.dto.StudentRequest;

public interface MyAdminDetailsService {
	
	public StudentConfirmation registerStudent(StudentRequest studentRequest);
	public ShowCourseConfirmation addCourse(CourseRequest courseRequest);
	public ShowCourseConfirmation updateCourse(CourseRequest courseRequest, Long id);
	public ShowCourseConfirmation deleteCourse(Long id);
	public ShowCourseConfirmation showCourse(Long id);
	public ShowCourseListConfirmation showAllCourse();
	public ShowCustomStudentListConfirmation showStudentByDate();
	public ShowCustomStudentListConfirmation showStudentWithoutFees();
	public ShowCustomStudentListConfirmation showStudentWithFees();
	public ShowStudentDetailsListConfirmation showCourseStudent(Long id);
	public ShowCustomStudentListConfirmation showStudentCourse(Long id);
	public Double showTotalFeeCollected();
	public Double showBalanceFeeCollected();
}
