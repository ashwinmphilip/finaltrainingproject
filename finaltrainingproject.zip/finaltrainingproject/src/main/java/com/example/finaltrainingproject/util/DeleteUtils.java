package com.example.finaltrainingproject.util;

import java.util.Iterator;
import java.util.List;

import com.example.finaltrainingproject.entity.StudentCourse;
import com.example.finaltrainingproject.exception.ObjectInUseException;

public class DeleteUtils {
	public static boolean validateDelete(List<StudentCourse> listo, Long id) {
		Iterator<StudentCourse> it = listo.iterator();
		while(it.hasNext()) {
			if(id == it.next().getCourseId()) {
				throw new ObjectInUseException("Objects in use cannot be deleted");
			}
		}
		return true;
	}
}
