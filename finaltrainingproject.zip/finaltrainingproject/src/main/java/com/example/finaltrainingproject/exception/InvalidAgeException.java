package com.example.finaltrainingproject.exception;

public class InvalidAgeException extends RuntimeException {
	public InvalidAgeException(String message) {
		super(message);
	}
}
