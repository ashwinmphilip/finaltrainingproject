package com.example.finaltrainingproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinaltrainingprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinaltrainingprojectApplication.class, args);
	}
}
