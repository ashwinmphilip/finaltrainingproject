package com.example.finaltrainingproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.finaltrainingproject.dto.ShowAcademicDetailsConfirmation;
import com.example.finaltrainingproject.dto.StudentCourseConfirmation;
import com.example.finaltrainingproject.dto.StudentCourseRequest;
import com.example.finaltrainingproject.dto.StudentDetailsRequest;
import com.example.finaltrainingproject.service.MyStudentDetailsServiceImpl;

@RestController
public class StudentController {
	
	@Autowired
	private MyStudentDetailsServiceImpl myStudentServiceImpl;
	
	@PostMapping("/studentupdate/{id}")
	public ShowAcademicDetailsConfirmation updateUser(@RequestBody StudentDetailsRequest studentDetailsRequest, @PathVariable("id") Long id) {
		return myStudentServiceImpl.updateStudent(studentDetailsRequest, id);
	}
	
	@GetMapping("/studentshow/{id}")
	public ShowAcademicDetailsConfirmation showUser(@PathVariable("username") Long id) {
		return myStudentServiceImpl.showStudent(id);
	}
	
	@PostMapping("/studentcourseregister/{id}")
	public StudentCourseConfirmation updateStudentCourse(@RequestBody StudentCourseRequest studentCourseRequest, @PathVariable("id") Long id) {
		return myStudentServiceImpl.updateStudentCourse(studentCourseRequest, id);
	}
	
}
