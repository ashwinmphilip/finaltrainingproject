package com.example.finaltrainingproject.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;

import org.springframework.stereotype.Service;

import com.example.finaltrainingproject.dto.CourseRequest;
import com.example.finaltrainingproject.dto.ShowCourseConfirmation;
import com.example.finaltrainingproject.dto.ShowCourseListConfirmation;
import com.example.finaltrainingproject.dto.ShowCustomStudentListConfirmation;
import com.example.finaltrainingproject.dto.ShowStudentDetailsListConfirmation;
import com.example.finaltrainingproject.dto.StudentConfirmation;
import com.example.finaltrainingproject.dto.StudentRequest;
import com.example.finaltrainingproject.entity.AcademicDetails;
import com.example.finaltrainingproject.entity.Course;
import com.example.finaltrainingproject.entity.StudentCourse;
import com.example.finaltrainingproject.entity.User;
import com.example.finaltrainingproject.repository.MyAcademicDetailsRepository;
import com.example.finaltrainingproject.repository.MyCourseRepository;
import com.example.finaltrainingproject.repository.MyStudentCourseRepository;
import com.example.finaltrainingproject.repository.MyUserRepository;
import com.example.finaltrainingproject.util.AgeUtils;
import com.example.finaltrainingproject.util.DeleteUtils;
import com.example.finaltrainingproject.util.EmailUtils;
import com.example.finaltrainingproject.util.PhoneUtils;

@Service
public class MyAdminDetailsServiceImpl implements MyAdminDetailsService {
	@Autowired
	private MyUserRepository myUserRepository;
	
	@Autowired
	private MyAcademicDetailsRepository myAcademicDetailsRepository;
	
	@Autowired
	private MyCourseRepository myCourseRepository;
	
	@Autowired
	private MyStudentCourseRepository myStudentCourseRepository;
	
	@Autowired
	private Course course;
	
	@Override
	@Transactional
	public StudentConfirmation registerStudent(StudentRequest studentRequest) {
		User user = studentRequest.getUser();
		user = myUserRepository.save(user);
		EmailUtils.validateEmail(user.getEmail());
		PhoneUtils.validatePhone(user.getPhone());
		AgeUtils.validateAge(user.getDateOfBirth());
		AcademicDetails academicDetails = studentRequest.getAcademicDetails();
		academicDetails.setId(user.getId());
		myAcademicDetailsRepository.save(academicDetails);
		return new StudentConfirmation(user, academicDetails);	
	}
	
	@Override
	public ShowCourseConfirmation addCourse(CourseRequest courseRequest) {
		Course course = courseRequest.getCourse();
		myCourseRepository.save(course);
		return new ShowCourseConfirmation(course);
	}

	@Override
	public ShowCourseConfirmation updateCourse(CourseRequest courseRequest, Long id) {
		course = courseRequest.getCourse();
		Optional<Course> opt = myCourseRepository.findById(id);
		course.setId(opt.get().getId());
		myCourseRepository.save(course);
		return new ShowCourseConfirmation(course);
	}

	@Override
	@Transactional
	public ShowCourseConfirmation deleteCourse(Long id) {
		List<StudentCourse> listo = myStudentCourseRepository.findAll();
		DeleteUtils.validateDelete(listo, id);
		Optional<Course> opt = myCourseRepository.findById(id);
		myCourseRepository.deleteById(id);
		return new ShowCourseConfirmation(opt.get());
	}

	@Override
	public ShowCourseConfirmation showCourse(Long id) {
		Optional<Course> opt = myCourseRepository.findById(id);
    	return new ShowCourseConfirmation(opt.get());
	}

	@Override
	public ShowCourseListConfirmation showAllCourse() {
		return new ShowCourseListConfirmation(myCourseRepository.findAll());
	}
	
	@Override
	public ShowCustomStudentListConfirmation showStudentByDate() {
		
		List<StudentCourse> listo = myStudentCourseRepository.findAll(Sort.by(Sort.Direction.ASC, "date"));
		List<String> list = new ArrayList<String>();
		Iterator<StudentCourse> it = listo.iterator();
		while(it.hasNext()) {
			StudentCourse sc = it.next();
			Optional<User> opt = myUserRepository.findById(sc.getStudentId());
			list.add(opt.get() + " : " + myCourseRepository.findCourseById(sc.getCourseId()).getCourseName() + " : " + sc.getDate());
		}
		return new ShowCustomStudentListConfirmation(list);
	}

	@Override
	public ShowCustomStudentListConfirmation showStudentWithoutFees() {
		List<StudentCourse> listo = myStudentCourseRepository.findByBalance(0);
		List<String> list = new ArrayList<String>();
		Iterator<StudentCourse> it = listo.iterator();
		while(it.hasNext()) {
			StudentCourse sc = it.next();
			Optional<User> opt = myUserRepository.findById(sc.getStudentId());
			list.add(opt.get() + " : " + myCourseRepository.findCourseById(sc.getCourseId()).getCourseName());
		}
		return new ShowCustomStudentListConfirmation(list);
	}

	@Override
	public ShowCustomStudentListConfirmation showStudentWithFees() {
		List<StudentCourse> listo = myStudentCourseRepository.findByBalanceGreaterThan(0);
		List<String> list = new ArrayList<String>();
		Iterator<StudentCourse> it = listo.iterator();
		while(it.hasNext()) {
			StudentCourse sc = it.next();
			Optional<User> opt = myUserRepository.findById(sc.getStudentId());
			list.add(opt.get() + " : " + myCourseRepository.findCourseById(sc.getCourseId()).getCourseName() +" : " + sc.getBalance());
		}
		return new ShowCustomStudentListConfirmation(list);
	}

	@Override
	public ShowStudentDetailsListConfirmation showCourseStudent(Long id) {
		List<StudentCourse> listo = myStudentCourseRepository.findByCourseId(id);
		List<StudentConfirmation> list = new ArrayList<StudentConfirmation>();
		Iterator<StudentCourse> it = listo.iterator();
		while(it.hasNext()) {
			StudentCourse sc = it.next();
			Optional<User> opt = myUserRepository.findById(sc.getStudentId());
			Optional<AcademicDetails> opto = myAcademicDetailsRepository.findById(sc.getStudentId());
			list.add(new StudentConfirmation(opt.get(), opto.get()));
		}
		return new ShowStudentDetailsListConfirmation(list);
	}

	@Override
	public ShowCustomStudentListConfirmation showStudentCourse(Long id) {
		List<StudentCourse> listo = myStudentCourseRepository.findByStudentId(id);
		List<String> list = new ArrayList<String>();
		Iterator<StudentCourse> it = listo.iterator();
		while(it.hasNext()) {
			Optional<Course> opt = myCourseRepository.findById(it.next().getCourseId());
			list.add(opt.get().getCourseName());
		}
		return new ShowCustomStudentListConfirmation(list);
	}

	@Override
	public Double showTotalFeeCollected() {
		double d = 0;
		List<StudentCourse> listo = myStudentCourseRepository.findAll();
		Iterator<StudentCourse> it = listo.iterator();
		while(it.hasNext()) {
			d = d + it.next().getAmount();
		}
		return d;
	}

	@Override
	public Double showBalanceFeeCollected() {
		double d = 0;
		List<StudentCourse> listo = myStudentCourseRepository.findAll();
		Iterator<StudentCourse> it = listo.iterator();
		while(it.hasNext()) {
			d = d + it.next().getBalance();
		}
		return d;
	}
	
}
