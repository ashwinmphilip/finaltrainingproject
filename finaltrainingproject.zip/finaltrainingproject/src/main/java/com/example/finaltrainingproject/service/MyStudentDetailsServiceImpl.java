package com.example.finaltrainingproject.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.finaltrainingproject.dto.ShowAcademicDetailsConfirmation;
import com.example.finaltrainingproject.dto.StudentCourseConfirmation;
import com.example.finaltrainingproject.dto.StudentCourseRequest;
import com.example.finaltrainingproject.dto.StudentDetailsRequest;
import com.example.finaltrainingproject.entity.AcademicDetails;
import com.example.finaltrainingproject.entity.StudentCourse;
import com.example.finaltrainingproject.repository.MyAcademicDetailsRepository;
import com.example.finaltrainingproject.repository.MyStudentCourseRepository;

@Service
public class MyStudentDetailsServiceImpl implements MyStudentDetailsService {
	
	@Autowired
	private MyAcademicDetailsRepository myAcademicDetailsRepository;
	
	@Autowired
	private MyStudentCourseRepository myStudentCourseRepository;
	
	@Autowired
	private AcademicDetails academicDetails;
	
	@Override
	public ShowAcademicDetailsConfirmation updateStudent(StudentDetailsRequest studentDetailsRequest, Long id) {
		
		academicDetails = studentDetailsRequest.getAcademicDetails();
		Optional<AcademicDetails> opt = myAcademicDetailsRepository.findById(id);
		academicDetails.setId(opt.get().getId());
		myAcademicDetailsRepository.save(academicDetails);
		return new ShowAcademicDetailsConfirmation(academicDetails);	
	}
	
    @Override
	public ShowAcademicDetailsConfirmation showStudent(Long id) {	
    	Optional<AcademicDetails> opt = myAcademicDetailsRepository.findById(id);
    	return new ShowAcademicDetailsConfirmation(opt.get());
	}

	@Override
	public StudentCourseConfirmation updateStudentCourse(StudentCourseRequest studentCourseRequest, Long id) {
		StudentCourse studentCourse = studentCourseRequest.getStudentCourse();
		studentCourse.setStudentId(id);
		myStudentCourseRepository.save(studentCourse);
		return new StudentCourseConfirmation(studentCourse);
	}

}
