package com.example.finaltrainingproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.finaltrainingproject.dto.CourseRequest;
import com.example.finaltrainingproject.dto.ShowCourseConfirmation;
import com.example.finaltrainingproject.dto.ShowCourseListConfirmation;
import com.example.finaltrainingproject.dto.ShowCustomStudentListConfirmation;
import com.example.finaltrainingproject.dto.ShowStudentDetailsListConfirmation;
import com.example.finaltrainingproject.dto.StudentConfirmation;
import com.example.finaltrainingproject.dto.StudentRequest;
import com.example.finaltrainingproject.service.MyAdminDetailsServiceImpl;

@RestController
public class AdminController {
	
	@Autowired
	private MyAdminDetailsServiceImpl myAdminServiceImpl;
	
	@PostMapping("/studentregister")
	public StudentConfirmation registerUser(@RequestBody StudentRequest studentRequest) {
		return myAdminServiceImpl.registerStudent(studentRequest);
	}
	
	@PostMapping("/courseregister")
	public ShowCourseConfirmation registerCourse(@RequestBody CourseRequest courseRequest) {
		return myAdminServiceImpl.addCourse(courseRequest);
	}
	
	@PostMapping("/courseupdate/{id}")
	public ShowCourseConfirmation updateCourse(@RequestBody CourseRequest courseRequest, @PathVariable("id") Long id) {
		return myAdminServiceImpl.updateCourse(courseRequest, id);
	}
	
	@GetMapping("/courseshow/{id}")
	public ShowCourseConfirmation showCourse(@PathVariable("id") Long id) {
		return myAdminServiceImpl.showCourse(id);
	}
	
	@DeleteMapping("/coursedelete/{id}")
	public ShowCourseConfirmation deleteCourse(@PathVariable("id") Long id) {
		return myAdminServiceImpl.deleteCourse(id);
	}
	
	@GetMapping("/allcourseshow")
	public ShowCourseListConfirmation showAllCourse() {
		return myAdminServiceImpl.showAllCourse();
	}
	
	@GetMapping("/studentshowbydate")
	public ShowCustomStudentListConfirmation showStudentByDate() {
		return myAdminServiceImpl.showStudentByDate();
	}
	
	@GetMapping("/studentshowwithoutfees")
	public ShowCustomStudentListConfirmation showStudentWithoutFees() {
		return myAdminServiceImpl.showStudentWithoutFees();
	}
	
	@GetMapping("/studentshowwithfees")
	public ShowCustomStudentListConfirmation showStudentWithFees() {
		return myAdminServiceImpl.showStudentWithFees();
	}
	
	@GetMapping("/coursestudentshow/{id}")
	public ShowStudentDetailsListConfirmation showCourseStudent(@PathVariable("id") Long id) {
		return myAdminServiceImpl.showCourseStudent(id);
	}
	
	@GetMapping("/studentcourseshow/{id}")
	public ShowCustomStudentListConfirmation showStudentCourse(@PathVariable("id") Long id) {
		return myAdminServiceImpl.showStudentCourse(id);
	}
	
	@GetMapping("/totalfees")
	public Double showTotalFeeCollected() {
		return myAdminServiceImpl.showTotalFeeCollected();
	}
	
	@GetMapping("/balancefees")
	public Double showBalanceFeeCollected() {
		return myAdminServiceImpl.showBalanceFeeCollected();
	}
}
