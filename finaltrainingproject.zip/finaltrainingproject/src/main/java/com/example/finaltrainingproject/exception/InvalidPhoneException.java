package com.example.finaltrainingproject.exception;

public class InvalidPhoneException extends RuntimeException {
	public InvalidPhoneException(String message) {
		super(message);
	}
}
